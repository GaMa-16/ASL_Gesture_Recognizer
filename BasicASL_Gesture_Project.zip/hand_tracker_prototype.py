import cv2
import mediapipe as mp
import time

# --- 1. INITIALIZE MEDIA PIPE TOOLS ---
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

# Start capturing video from your webcam (usually index 0)
cap = cv2.VideoCapture(0)

print("Starting Hand Tracking Prototype. Press 'q' to quit...")

# --- 2. START THE HAND TRACKING SESSION ---
with mp_hands.Hands(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5) as hands:

    while cap.isOpened():
        success, image = cap.read()
        if not success:
            print("Ignoring empty camera frame.")
            continue

        # Flip the image horizontally for a 'selfie' view and convert colors
        image = cv2.flip(image, 1)
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # --- 3. PROCESS THE FRAME WITH THE AI MODEL ---
        results = hands.process(image_rgb)

        # --- 4. DRAW THE RESULTS ---
        if results.multi_hand_landmarks:
            # Loop through every hand MediaPipe found
            for hand_landmarks in results.multi_hand_landmarks:
                # Draw the dots and lines (the skeleton) on the original image
                mp_drawing.draw_landmarks(
                    image, hand_landmarks, mp_hands.HAND_CONNECTIONS,
                    mp_drawing.DrawingSpec(color=(0, 0, 255), thickness=2, circle_radius=4), # Blue dots
                    mp_drawing.DrawingSpec(color=(0, 255, 0), thickness=2, circle_radius=2)) # Green lines
                
        # --- 5. DISPLAY THE VIDEO FEED ---
        cv2.putText(image, "Hand Tracking Active (Press 'q' to quit)", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imshow('Real-Time Hand Tracker', image)

        # Exit the loop if the 'q' key is pressed
        if cv2.waitKey(5) & 0xFF == ord('q'):
            break

# --- 6. CLEAN UP ---
cap.release()
cv2.destroyAllWindows()