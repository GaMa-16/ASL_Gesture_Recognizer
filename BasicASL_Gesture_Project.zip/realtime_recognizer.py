import cv2
import mediapipe as mp
import numpy as np
from tensorflow.keras.models import load_model
from collections import Counter 

# --- 1. CONFIGURATION (MUST MATCH TRAINING) ---
actions = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'None']
TARGET_FRAME_COUNT = 20  
THRESHOLD = 0.90 # Set a high threshold for stability

# --- DISPLAY SETTINGS (Your Custom Pink/White Look) ---
WHITE = (255, 255, 255)
PINK = (255, 0, 255) # BGR
BLACK = (0, 0, 0)

# --- 2. LOAD AI MODEL AND UTILITIES ---
# NOTE: Update the model file name in Step 4 to match your new model!
try:
    model = load_model('Models/best_gesture_model_26.h5') 
except:
    print("ERROR: Model 'best_gesture_model_26.h5' not found. Ensure training finished successfully.")
    exit()

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

# --- 3. HELPER FUNCTION: EXTRACT & NORMALIZE LANDMARKS (THE FIXED VERSION) ---
def extract_landmarks(results):
    """
    Extracts 21 hand landmarks, normalized relative to the wrist (landmark 0).
    MUST be identical across all three scripts.
    """
    if results.multi_hand_landmarks:
        hand_landmarks = results.multi_hand_landmarks[0].landmark
        
        wrist_x = hand_landmarks[0].x
        wrist_y = hand_landmarks[0].y
        wrist_z = hand_landmarks[0].z
        
        hand_coords = []
        for landmark in hand_landmarks:
            hand_coords.extend([landmark.x - wrist_x, 
                                landmark.y - wrist_y, 
                                landmark.z - wrist_z])
            
        return np.array(hand_coords).flatten()
    else:
        return np.zeros(21*3)

# --- 4. REAL-TIME RECOGNITION LOOP ---
cap = cv2.VideoCapture(0)
sequence = []
predictions = [] 

with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
    while cap.isOpened():
        success, image = cap.read()
        if not success: continue

        image = cv2.flip(image, 1)
        image_height, image_width, _ = image.shape
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image_rgb)
        
        # Skeleton drawing and data extraction
        if results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(image, results.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS)
            keypoints = extract_landmarks(results)
            sequence.append(keypoints)
        else:
            sequence.append(np.zeros(21*3))

        sequence = sequence[-TARGET_FRAME_COUNT:] 
        
        predicted_action = "Buffering..."
        confidence = 0.0
        
        if len(sequence) == TARGET_FRAME_COUNT:
            X = np.expand_dims(sequence, axis=0) 
            res = model.predict(X, verbose=0)[0] 
            prediction_index = np.argmax(res)
            confidence = res[prediction_index]
            
            if confidence > THRESHOLD:
                predictions.append(actions[prediction_index])
            else:
                predictions.append("Uncertain")
                
            if len(predictions) > 10:
                predictions = predictions[-10:]

            # --- PREDICTION SMOOTHING (Majority Voting) ---
            most_common, count = Counter(predictions).most_common(1)[0]
            
            if most_common in actions:
                final_display_text = f'{most_common}'
            else:
                final_display_text = "Uncertain"
            
            acc_text = f'Accuracy: {confidence*100:.1f}%'
            
        else:
            final_display_text = "Buffering..."
            acc_text = ""


        # --- CUSTOM DISPLAY BOX LOGIC ---
        box_width = 300
        box_height = 100
        box_x_start = image_width - box_width - 10 
        box_y_start = image_height - box_height - 10 
        
        # 2. Draw the white background box
        cv2.rectangle(image, 
                      (box_x_start, box_y_start), 
                      (image_width - 10, image_height - 10), 
                      WHITE, 
                      -1) 

        # 3. Put the large pink prediction text
        cv2.putText(image, 
                    final_display_text, 
                    (box_x_start + 10, box_y_start + 40), 
                    cv2.FONT_HERSHEY_DUPLEX, 
                    1.2, 
                    PINK, 
                    2, 
                    cv2.LINE_AA)

        # 4. Put the smaller black accuracy text
        cv2.putText(image, 
                    acc_text, 
                    (box_x_start + 10, box_y_start + 80), 
                    cv2.FONT_HERSHEY_SIMPLEX, 
                    0.6, 
                    BLACK, 
                    1, 
                    cv2.LINE_AA)
        
        cv2.imshow('Real-Time Gesture Recognition', image)

        if cv2.waitKey(5) & 0xFF == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()