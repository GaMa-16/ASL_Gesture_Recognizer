import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
import os

# --- 1. CONFIGURATION (26-Letter Scope) ---
actions = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'None']
num_classes = len(actions) 
TARGET_FRAME_COUNT = 20

# --- 2. LOAD PREPARED DATA (Using new file names) ---
try:
    X_train = np.load('X_train_26.npy')
    X_test = np.load('X_test_26.npy')
    y_train = np.load('y_train_26.npy')
    y_test = np.load('y_test_26.npy')
    
    print("--- Data Loaded Successfully ---")
    
except FileNotFoundError:
    print("ERROR: Could not find one or more '_26.npy' files. Ensure data_processor.py ran correctly.")
    exit()

# --- 3. DEFINE THE NEURAL NETWORK ARCHITECTURE ---
frames_per_sequence = X_train.shape[1]
features_per_frame = X_train.shape[2]

model = Sequential()
model.add(LSTM(64, return_sequences=True, activation='relu', input_shape=(frames_per_sequence, features_per_frame)))
model.add(LSTM(128, return_sequences=True, activation='relu'))
model.add(LSTM(64, return_sequences=False, activation='relu'))
model.add(Dense(64, activation='relu'))
model.add(Dense(num_classes, activation='softmax')) # Output layer matches 27 classes

# --- 4. COMPILE AND DEFINE CALLBACKS ---
model.compile(optimizer='Adam', loss='categorical_crossentropy', metrics=['categorical_accuracy'])

# New model save name
checkpoint_filepath = os.path.join('Models', 'best_gesture_model_26.h5')
os.makedirs(os.path.dirname(checkpoint_filepath), exist_ok=True)
model_checkpoint = ModelCheckpoint(filepath=checkpoint_filepath, 
                                 monitor='val_loss', 
                                 save_best_only=True,
                                 verbose=1)
early_stopping = EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True)


# --- 5. TRAIN THE MODEL ---
print("\n--- Starting Model Training ---")
history = model.fit(X_train, y_train, 
                    epochs=200, 
                    callbacks=[early_stopping, model_checkpoint], 
                    validation_data=(X_test, y_test), 
                    batch_size=32)

print("\n--- Model Training Complete ---")
print(f"New best model saved to: {checkpoint_filepath}")

# --- 6. EVALUATE THE MODEL ---
loss, accuracy = model.evaluate(X_test, y_test, verbose=1)
print(f"\nFinal Test Accuracy: {accuracy*100:.2f}%")