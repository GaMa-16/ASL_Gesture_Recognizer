import numpy as np
import os
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical

# --- CONFIGURATION (MUST MATCH collector.py) ---
DATA_PATH = os.path.join('MP_Data_26') 
actions = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'None']
no_sequences = 15 
TARGET_FRAME_COUNT = 20 # Fixed frame count for consistent shape

# Create a mapping from gesture name (string) to a number (integer)
label_map = {label:num for num, label in enumerate(actions)}

sequences, labels = [], []

# --- 3. HELPER FUNCTION: EXTRACT & NORMALIZE LANDMARKS (FIXED - Not used here, but needed for consistency check) ---
# NOTE: The processor script does not need the function body, but relies on the collector's output shape.

# --- 4. LOAD DATA FROM FOLDERS (FIXED FRAME LOGIC) ---
print("Starting data loading and standardization...")
for action in actions:
    for sequence in range(no_sequences):
        window = []
        sequence_folder = os.path.join(DATA_PATH, action, str(sequence))
        
        if not os.path.exists(sequence_folder): continue # Skip if folder was not created

        frame_files = sorted(os.listdir(sequence_folder), key=lambda x: int(os.path.splitext(x)[0]))
        
        # --- ENSURE CONSISTENT FRAME COUNT (The Shape Fix) ---
        for i in range(TARGET_FRAME_COUNT):
            if i < len(frame_files):
                frame_file = frame_files[i]
                res = np.load(os.path.join(sequence_folder, frame_file))
                window.append(res)
            else:
                window.append(np.zeros(21*3)) # Pad with zeros if short

        if len(window) == TARGET_FRAME_COUNT:
            sequences.append(window) 
            labels.append(label_map[action])

X = np.array(sequences)
Y = to_categorical(labels).astype(int) 

# --- 5. SPLIT DATA FOR TRAINING AND TESTING ---
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

print("\n--- Data Processing Summary ---")
print(f"Total sequences loaded: {X.shape[0]}")
print(f"Input Shape (X): {X.shape} ({X.shape[0]} sequences x {TARGET_FRAME_COUNT} frames x 63 features)") 

# Save the prepared data arrays
np.save('X_train_26.npy', X_train) # Use a new file name
np.save('X_test_26.npy', X_test)
np.save('y_train_26.npy', y_train)
np.save('y_test_26.npy', y_test)

print("\nData preparation complete. Saved files with '_26' suffix. Ready for Training!")