import cv2
import mediapipe as mp
import numpy as np
import os
import time

# --- 1. SETUP: VARIABLES AND CONSTANTS ---
DATA_PATH = os.path.join('MP_Data_26') # New folder name for the 26-letter dataset
actions = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'None'] # 26 letters + 'None'
no_sequences = 15     # Total number of recordings (sequences) per gesture
RECORD_DURATION_SECONDS = 1.0 # Duration of active recording per sequence

# --- 2. SETUP: MEDIA PIPE UTILITIES ---
mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands

# --- 3. HELPER FUNCTION: EXTRACT & NORMALIZE LANDMARKS (FIXED) ---
def extract_landmarks(results):
    """
    Extracts 21 hand landmarks, normalized relative to the wrist (landmark 0).
    MUST be identical across all three scripts.
    """
    if results.multi_hand_landmarks:
        hand_landmarks = results.multi_hand_landmarks[0].landmark
        
        # 1. Get the coordinates of the WRIST (Landmark 0) as the reference point
        wrist_x = hand_landmarks[0].x
        wrist_y = hand_landmarks[0].y
        wrist_z = hand_landmarks[0].z
        
        # 2. Calculate coordinates RELATIVE to the WRIST (Normalization)
        hand_coords = []
        for landmark in hand_landmarks:
            hand_coords.extend([landmark.x - wrist_x, 
                                landmark.y - wrist_y, 
                                landmark.z - wrist_z])
            
        return np.array(hand_coords).flatten()
    else:
        return np.zeros(21*3) 


# --- 4. START VIDEO CAPTURE AND DATA RECORDING ---
cap = cv2.VideoCapture(0)

# Create the data folder structure
for action in actions:
    for sequence in range(no_sequences):
        try: 
            os.makedirs(os.path.join(DATA_PATH, action, str(sequence)))
        except:
            pass 

print(f"Data collection script active. Press 'p' to PAUSE, 'q' to QUIT. Each sequence records for {RECORD_DURATION_SECONDS} second(s).")

with mp_hands.Hands(min_detection_confidence=0.5, min_tracking_confidence=0.5) as hands:
    
    for action in actions:
        for sequence in range(no_sequences):
            
            frame_num = 0
            start_time = time.time()
            record_start_time = 0
            is_recording = False
            
            while True:
                success, image = cap.read()
                if not success: continue

                image = cv2.flip(image, 1)
                image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                results = hands.process(image_rgb)
                
                if results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(image, results.multi_hand_landmarks[0], mp_hands.HAND_CONNECTIONS)
                    
                elapsed_time = time.time() - start_time
                status_text = 'GET READY'
                color = (0, 255, 255) # Yellow
                
                if elapsed_time >= 1.0 and not is_recording:
                    is_recording = True
                    record_start_time = time.time()
                
                if is_recording:
                    record_elapsed = time.time() - record_start_time
                    
                    if record_elapsed < RECORD_DURATION_SECONDS:
                        status_text = f'RECORDING: {RECORD_DURATION_SECONDS - round(record_elapsed, 1)}s left'
                        color = (0, 0, 255) # Red
                        
                        # Extract and save the CORRECTLY NORMALIZED landmarks
                        keypoints = extract_landmarks(results)
                        npy_path = os.path.join(DATA_PATH, action, str(sequence), f"{frame_num}.npy")
                        np.save(npy_path, keypoints)
                        frame_num += 1
                        
                    else:
                        break # Recording duration complete

                cv2.putText(image, status_text, (120, 200), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, color, 4, cv2.LINE_AA)
                cv2.putText(image, f'Collecting for: {action} Sequence: {sequence}', (15, 12), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
                
                cv2.imshow('OpenCV Feed - Data Collector', image)

                # --- KEYBOARD CHECKS (Pause/Quit) ---
                key = cv2.waitKey(10) & 0xFF
                if key == ord('q'):
                    cap.release()
                    cv2.destroyAllWindows()
                    exit()
                if key == ord('p'):
                    print("\n--- Recording PAUSED. Press ENTER in the TERMINAL to resume. ---")
                    input() 
                    print("--- Recording RESUMED. ---")
            
            time.sleep(0.5) # Pause between sequences

cap.release()
cv2.destroyAllWindows()